package com.tuling.demo.test;

/**
 * Created by Tommy on 2018/3/6.
 */
public class UserServiceImpl {
    public void getUser() {
        System.out.println("user is luban");
    }

    public void  addUser(String name, String sex) {
        System.out.println(name + sex);

    }
    public void addUser2(String name, String sex) {
        System.out.println(name + sex);
    }
}
