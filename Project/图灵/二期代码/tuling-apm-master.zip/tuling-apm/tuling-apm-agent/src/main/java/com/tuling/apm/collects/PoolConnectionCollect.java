package com.tuling.apm.collects;

/**
 * Created by Tommy on 2018/3/11.
 */
public class PoolConnectionCollect {

    public void begin(){

    }

    public void end(){
     // 访问连接池对象的
       Object p=null;
      // 反谢
    }
}
