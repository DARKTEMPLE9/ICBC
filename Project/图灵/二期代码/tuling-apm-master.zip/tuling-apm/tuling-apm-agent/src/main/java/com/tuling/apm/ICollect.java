package com.tuling.apm;

/**
 * Created by Tommy on 2018/3/8.
 */
public interface ICollect {

}
