package com.tuling.plugin;

import com.tuling.teach.spring.pluginConsole;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

/**
 * Created by Tommy on 2017/10/24.
 */
public class Monitoring implements MethodInterceptor,pluginConsole {
    private ArrayList logs = new ArrayList(4096);

    public Object invoke(MethodInvocation invocation) throws Throwable {
        long begin = System.currentTimeMillis();
        String error = "";
        Object result = null;
        try {
            result = invocation.proceed();
        } catch (Throwable throwable) {
            error = throwable.getMessage();
            throw throwable;
        } finally {
            String className = invocation.getThis().getClass().getName();
            String methodName = invocation.getMethod().getName();
            String time = SimpleDateFormat.getDateTimeInstance().format(new Date());
            long end = System.currentTimeMillis();
             logs.add(logs);
        }
        return result;
    }

    public String getStatus() {
        StringBuilder builder=new StringBuilder();
        for (Object log : logs) {
            builder.append(log);
            builder.append("\r\n");
        }
        return builder.toString();
    }

    public String command(String cmd) {
        return null;
    }
}
