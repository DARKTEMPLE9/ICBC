package com.tuling.plugin;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import com.tuling.teach.spring.pluginConsole;
import org.springframework.aop.MethodBeforeAdvice;

/**
 * 输出Bean方法执行日志
 * 
 * @author Tommy
 *
 */
public class ServerLogPlugin implements MethodBeforeAdvice ,pluginConsole {
	private ArrayList logs=new ArrayList(4096);

	public void before(Method method, Object[] args, Object target) throws Throwable {
		String time = SimpleDateFormat.getDateTimeInstance().format(new Date());

		String log = String.format("%s %s.%s() 参数:%s",time, method.getDeclaringClass().getName(), method.getName(),
				Arrays.toString(args));
		logs.add(log);
		System.out.println(log);
	}


	public String getStatus() {
		StringBuilder builder=new StringBuilder();
		for (Object log : logs) {
			builder.append(log);
			builder.append("\r\n");
		}
		return builder.toString();
	}

	public String command(String cmd) {
		return null;
	}
}
