package com.tuling.teach.server;

public interface UserService {
	public String getName(String id);
}
