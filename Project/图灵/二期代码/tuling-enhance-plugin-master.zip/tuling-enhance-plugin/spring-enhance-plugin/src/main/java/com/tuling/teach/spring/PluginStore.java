package com.tuling.teach.spring;

import java.util.Date;
import java.util.List;

public class PluginStore implements java.io.Serializable {
	// 最后修改时间
	private Date lastModify;
	// 插件库
	private List<PluginConfig> plugins;

	public Date getLastModify() {
		return lastModify;
	}

	public void setLastModify(Date lastModify) {
		this.lastModify = lastModify;
	}

	public List<PluginConfig> getPlugins() {
		return plugins;
	}

	public void setPlugins(List<PluginConfig> plugins) {
		this.plugins = plugins;
	}

}
