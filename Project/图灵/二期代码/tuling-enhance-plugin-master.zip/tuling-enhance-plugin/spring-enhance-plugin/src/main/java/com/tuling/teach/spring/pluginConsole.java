package com.tuling.teach.spring;

public interface pluginConsole {
	public String getStatus();

	public String command(String cmd);
}
