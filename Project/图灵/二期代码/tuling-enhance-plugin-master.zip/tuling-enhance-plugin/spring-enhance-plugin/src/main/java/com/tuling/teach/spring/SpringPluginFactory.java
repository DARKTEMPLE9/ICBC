package com.tuling.teach.spring;

import java.util.List;
// 理清思路
//
public interface SpringPluginFactory {
	
	/**
	 * 激活指定插件
	 * 
	 * @param pluginId
	 */
	public void activePlugin(String pluginId);

	/**
	 * 禁用指定插件
	 * 
	 * @param pluginId
	 */
	public void disablePlugin(String pluginId);
	
	/**
	 * 安装插件
	 * 1、打开用户指定的插件中心, 展示插件列表
	 * 2、解析插件站点提供的插件配置描述（下载地址）
	 * 3、下载至本地
	 * 4、验证插件的合法性、插件对应的版本是否在本地已经在存？
	 * 5、装载插件JAR包至我们的ClassLoader
	 * 6、基于AOP 切入我们的监控逻辑
	 * @param plugin
	 */
	public void installPlugin(PluginConfig plugin,Boolean load);
	
	/**
	 * 卸载插件
	 * @param id
	 */
	public void uninstallPlugin(String id);

	/**
	 *  插件列表获取
	 * @return
	 */
	public List<PluginConfig> getPluginList();

	/**
	 * 插件状态获取
	 * @param id
	 * @return
	 */
	public String getPluginStatus(String id);
	
}
