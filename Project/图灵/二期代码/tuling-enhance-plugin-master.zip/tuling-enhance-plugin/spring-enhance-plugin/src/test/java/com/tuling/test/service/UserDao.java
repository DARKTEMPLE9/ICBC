package com.tuling.test.service;

public interface UserDao {
	
}
