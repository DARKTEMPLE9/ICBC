package com.tuling.test.service;

public interface UserService {
	String getUser();

	String setUser();

	void addUser(String name);
}
