package test.collects.dubbo;

import test.collects.BasiceTest;

/**
 * Created by tommy on 16/10/22.
 */
public class DubboConsumerHandTest extends BasiceTest {

}
