package com.cbt.agent.common;

public interface JsonSerializable extends java.io.Serializable {
    public String toJsonString();
}
