package com.test;

import com.tuling.agent.LubanServer;

/**
 * @author Tommy
 * Created by Tommy on 2019/3/22
 **/
public class ServerAgentTest {
    public static void main(String[] args) {
        new LubanServer().sayHello("luban", "good man");
    }
}
