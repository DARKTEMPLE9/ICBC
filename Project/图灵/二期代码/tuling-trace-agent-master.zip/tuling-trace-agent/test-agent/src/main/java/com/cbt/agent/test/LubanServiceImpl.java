package com.cbt.agent.test;/**
 * Created by Administrator on 2018/6/19.
 */

/**
 * @author Tommy
 *         Created by Tommy on 2018/6/19
 **/
public class LubanServiceImpl {
    public LubanServiceImpl() {

    }

    public void hello(String luban, String hello) {
        {  // 开始时间
            hello$agent(luban, hello);
            // 结束时间
        }
    }

    public void hello$agent(String luban, String hello) {

        String p1 = "";
        String p2 = "";
        String p3 = "";

    }
}
