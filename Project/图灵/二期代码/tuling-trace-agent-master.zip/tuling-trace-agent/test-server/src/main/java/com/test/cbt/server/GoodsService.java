package com.test.cbt.server;/**
 * Created by Administrator on 2018/6/8.
 */

/**
 * @author Tommy
 *         Created by Tommy on 2018/6/8
 **/
public interface GoodsService {
    Goods getGoods(Long goodsId);
}
