package com.jiagouedu.znode;/* ━━━━━━如来保佑━━━━━━
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━永无BUG━━━━━━
 * 图灵学院-悟空老师
 * 以往视频加小乔老师QQ：895900009
 * 悟空老师QQ：245553999
 */

import com.jiagouedu.zkclient.znode.ZkClientCrud;

public class ZkclientTest {
   public static void main(String[] args) {
      ZkClientCrud zkClientCrud=new ZkClientCrud();
      User user=new User();
      user.setAge(18);
      user.setName("wukong");
      zkClientCrud.createPersistent("/abc",user);
      System.out.println(zkClientCrud.readData("/abc"));;



   }
}
