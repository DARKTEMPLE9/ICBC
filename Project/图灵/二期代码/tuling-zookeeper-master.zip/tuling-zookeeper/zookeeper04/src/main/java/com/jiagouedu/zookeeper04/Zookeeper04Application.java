package com.jiagouedu.zookeeper04;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class Zookeeper04Application {

	public static void main(String[] args) {
		SpringApplication.run(Zookeeper04Application.class, args);
	}
}
