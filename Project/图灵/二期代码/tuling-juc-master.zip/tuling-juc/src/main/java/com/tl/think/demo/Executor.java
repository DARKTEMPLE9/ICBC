package com.tl.think.demo;

/**
 * @Author: xue.l
 * @Date: 2018/9/20 11:22
 * @Description:
 * @Version: 1.0.0
 */
public interface Executor {

    void execute(Runnable command);
}
