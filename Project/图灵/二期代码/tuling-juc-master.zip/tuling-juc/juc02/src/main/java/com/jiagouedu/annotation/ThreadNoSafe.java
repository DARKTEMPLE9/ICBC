package com.jiagouedu.annotation;


/***
 * 非线程安全的
 */
public @interface ThreadNoSafe {
}
