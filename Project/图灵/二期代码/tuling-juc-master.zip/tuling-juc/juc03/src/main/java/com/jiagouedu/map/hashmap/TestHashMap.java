package com.jiagouedu.map.hashmap;/*
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　永无BUG 　┣┓
 * 　　　　┃　　如来保佑　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┗┻┛　┗┻┛
 */



public class TestHashMap {


  public   static void main(String[] args) {
    Map<String,String> map=new HashMap<String,String>();
    map.put("wukong","悟空");
    System.out.println(map.get("wukong"));
  }

}
