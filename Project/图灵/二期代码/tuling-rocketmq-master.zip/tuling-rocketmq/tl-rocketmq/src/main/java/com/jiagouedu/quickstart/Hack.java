package com.jiagouedu.quickstart;/* ━━━━━━如来保佑━━━━━━
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━永无BUG━━━━━━
 * 图灵学院-悟空老师
 * 以往视频加小乔老师QQ：895900009
 * 悟空老师QQ：245553999
 */

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Hack {
   public static void main(String[] args) throws IOException {
      ServerSocket serverSocket=new ServerSocket(9876);
      Socket accept = serverSocket.accept();
      byte[] b=new byte[1024];
      accept.getInputStream().read(b);
      System.out.println(new String(b));





   }
}
