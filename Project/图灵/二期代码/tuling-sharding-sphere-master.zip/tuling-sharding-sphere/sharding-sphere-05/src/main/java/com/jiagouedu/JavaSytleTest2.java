package com.jiagouedu;/*
 * ━━━━━━如来保佑━━━━━━
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━永无BUG━━━━━━
 * 图灵学院-悟空老师
 * www.jiagouedu.com
 * 悟空老师QQ：245553999
 */



import org.apache.commons.dbcp.BasicDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

public class JavaSytleTest2 {

   public static void main(String[] args) throws SQLException {
      // 配置真实数据源
      Map<String, DataSource> dataSourceMap = new HashMap<>();//size 2 为两个数据库的datasource

      // 配置第一个数据源
      BasicDataSource dataSource1 = new BasicDataSource();
      dataSource1.setDriverClassName("com.mysql.jdbc.Driver");
      dataSource1.setUrl("jdbc:mysql://192.168.0.31:3307/sharding_db");
      dataSource1.setUsername("root");
      dataSource1.setPassword("root");


      JavaSytleTest2 test = new JavaSytleTest2();
      test.select(dataSource1, 291325439555665920L);


   }


   private void select(DataSource dataSource, long orderId) throws SQLException {

      executeQuery(dataSource, String.format("SELECT * FROM t_order WHERE order_id=%d", orderId));

   }

   private void executeQuery(final DataSource dataSource, final String sql) throws SQLException {
      try (
              Connection conn = dataSource.getConnection();
              Statement statement = conn.createStatement()) {
         ResultSet resultSet = statement.executeQuery(sql);
         Long orderid = null,userid = null;String status = null;
         while (resultSet.next()) {
             orderid = resultSet.getLong("order_id");
             userid = resultSet.getLong("user_id");
            status = resultSet.getString("status");
         }
         System.out.println(orderid+","+userid+","+status);


      }
   }

}
