package com.jiagouedu;/* ━━━━━━如来保佑━━━━━━
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　┻　　　┃
 * 　　┗━┓　　　┏━┛
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　　┣┓
 * 　　　　┃　　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┗┻┛　┗┻┛
 * ━━━━━━永无BUG━━━━━━
 * 图灵学院-悟空老师
 * 以往视频加小乔老师QQ：895900009
 * 悟空老师QQ：245553999
 */

import io.shardingsphere.core.keygen.DefaultKeyGenerator;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Test {

   public static void main(String[] args) {
      DefaultKeyGenerator defaultKeyGenerator=new DefaultKeyGenerator();//类锁 请求都创建一次
      Map map=new ConcurrentHashMap();
      TlUtil.timeTasks(1000, 1, new Runnable() {
         @Override
         public void run() {
           // System.out.println(defaultKeyGenerator.generateKey());
            map.put(defaultKeyGenerator.generateKey(),defaultKeyGenerator.generateKey());;
         }
      });
      System.out.println(map.size());


   }
}
