/**
 * getXXX方法的接口和抽象实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.getter;