/**
 * 文件监听中的观察者实现类，包括延迟处理、处理链等
 * 
 * @author looly
 *
 */
package cn.hutool.core.io.watch.watchers;