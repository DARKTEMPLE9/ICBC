/**
 * 锁的实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.thread.lock;