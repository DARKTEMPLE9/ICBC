/**
 * 注解包，提供增强型注解和注解工具类
 * 
 * @author looly
 *
 */
package cn.hutool.core.annotation;