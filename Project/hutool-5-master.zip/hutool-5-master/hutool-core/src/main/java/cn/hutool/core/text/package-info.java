/**
 * 提供文本相关操作的封装，还包括Unicode工具UnicodeUtil
 * 
 * @author looly
 *
 */
package cn.hutool.core.text;