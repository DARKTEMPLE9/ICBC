/**
 * 提供各种转义和反转义实现
 * 
 * @author looly
 *
 */
package cn.hutool.core.text.escape;