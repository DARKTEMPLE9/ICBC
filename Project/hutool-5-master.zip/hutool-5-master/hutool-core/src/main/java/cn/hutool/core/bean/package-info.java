/**
 * Bean相关操作，包括Bean信息描述，Bean路径表达式、动态Bean、Bean工具等
 * 
 * @author looly
 *
 */
package cn.hutool.core.bean;