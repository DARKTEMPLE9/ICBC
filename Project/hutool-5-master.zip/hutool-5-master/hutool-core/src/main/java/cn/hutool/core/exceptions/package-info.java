/**
 * 特殊异常封装，同时提供异常工具ExceptionUtil
 * 
 * @author looly
 *
 */
package cn.hutool.core.exceptions;