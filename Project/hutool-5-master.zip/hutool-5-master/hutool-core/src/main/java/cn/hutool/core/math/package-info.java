/**
 * 提供数学计算相关封装，包括排列组合等，入口为MathUtil
 * 
 * @author looly
 *
 */
package cn.hutool.core.math;