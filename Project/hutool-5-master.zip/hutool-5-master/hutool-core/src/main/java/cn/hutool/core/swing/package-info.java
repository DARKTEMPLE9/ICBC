/**
 * Swing和awt相关封装
 * 
 * @author looly
 *
 */
package cn.hutool.core.swing;