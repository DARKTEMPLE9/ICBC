/**
 * 提供针对文件的缓存实现
 * 
 * @author looly
 *
 */
package cn.hutool.cache.file;