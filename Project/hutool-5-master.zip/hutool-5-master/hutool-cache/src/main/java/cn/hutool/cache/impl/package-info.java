/**
 * 提供各种缓存实现
 * 
 * @author looly
 *
 */
package cn.hutool.cache.impl;