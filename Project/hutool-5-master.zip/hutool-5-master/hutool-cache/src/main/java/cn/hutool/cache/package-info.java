/**
 * 提供简易的缓存实现，此模块参考了jodd工具中的Cache模块
 * 
 * @author looly
 *
 */
package cn.hutool.cache;